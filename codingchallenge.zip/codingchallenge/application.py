
# BOILERPLATE CODE # ======================


from flask import Flask, render_template, jsonify, request
from threading import Lock
from flask_cors import CORS
from flask_socketio import SocketIO
from flask_socketio import emit
import backend

app = Flask(__name__)
app.config['SECRET_KEY'] = 'secret!'
async_mode = None
CORS(app)
socketio = SocketIO(app,engineio_logger=True, async_mode=async_mode)
thread = None
thread_lock = Lock()

connections = {}

@app.route('/')
def home():
	return render_template('base.html', title='People App', async_mode=socketio.async_mode)


@socketio.on('show_people')
def show_people():
	people_data = backend.get_specific_data("people")
	print(people_data)
	socketio.emit('people_data', people_data, broadcast=False, include_self=True)
	return

@socketio.on('show_oldest')
def show_oldest():
	oldest_data = backend.find_oldest_person()
	print(oldest_data)
	socketio.emit('oldest_data', oldest_data, broadcast=False, include_self=True)
	return

@socketio.on('show_youngest')
def show_youngest():
	youngest_data = backend.find_youngest_person()
	print(youngest_data)
	socketio.emit('youngest_data', youngest_data, broadcast=False, include_self=True)
	return



@socketio.on('show_avg')
def show_avg():
	avg_data = backend.find_average_age()
	print(avg_data)
	socketio.emit('avg_data', avg_data, broadcast=False, include_self=True)
	return




if __name__ == "__main__":
	socketio.run(app, port=8080, debug=True)


# BOILERPLATE CODE # ======================



