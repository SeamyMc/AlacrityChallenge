import json
def get_data():
	with open("database.json") as db:
		data = json.load(db)
	return data


def get_specific_data(query):
	data = get_data()[query]
	return data


def find_oldest_person():
	people = get_specific_data("people")
	oldest = people[0]

	for person in people:
		if person["age"] > oldest["age"]:
			oldest = person

	return oldest


def find_youngest_person():
	people = get_specific_data("people")
	youngest = people[0]

	for person in people:
		if person["age"] < youngest["age"]:
			youngest = person

	return youngest


def get_average_age():
	people = get_specific_data("people")
	total_age = 0
	for person in people:
		total_age += int(person["age"])

	avg_age = total_age/len(people)

	return avg_age


def test_functions():
	print(f'data: {get_data()}')
	print(f'oldest:{find_oldest_person()}')
	print(f'youngest: {find_youngest_person()}')
	print(f'average age: {get_average_age()}')
	return



#test_functions()