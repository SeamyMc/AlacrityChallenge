

const socket = io.connect('http://' + document.domain + ':' + location.port);

$( "#show_people_btn" ).click(function() {
	socket.emit('show_people');

});

$( "#show_oldest_btn" ).click(function() {
	socket.emit('show_oldest');

});

$( "#show_youngest_btn" ).click(function() {
	socket.emit('show_youngest');

});

$( "#show_avg_btn" ).click(function() {
	socket.emit('show_avg');

});


socket.on("people_data", (people_data) => {
	alert(people_data[0]["name"])

	// for (i=0; i < people_data)
	// $( "#show_people_btn" ).append(person)
});


socket.on("oldest_data", (oldest_data) => {
	alert("oldest person is "  + oldest_data["name"] + " who is " + oldest_data["age"] + " years old")

});

socket.on("youngest_data", (youngest_data) => {
	alert("youngest person is "  + youngest_data["name"] + " who is " + youngest_data["age"] + " years old")

});

// socket.on("avg_data", (avg_data) => {
// 	alert("Average age is " + avg_data

// });